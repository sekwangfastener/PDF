export function Footer() {
  return (
    <footer className="bg-zinc-900 text-white py-8 md:py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-sm">
          <div>
            <h4 className="font-medium mb-3">본사</h4>
            <p className="text-zinc-400">경기도 남양주시 진접읍 부마로 54-16</p>
            <p className="text-zinc-400 mt-4">© 세광정밀 All rights reserved.</p>
          </div>
          <div>
            <h4 className="font-medium mb-3">연락처</h4>
            <p className="text-zinc-400">Fax 031)571 - 3567</p>
            <p className="text-zinc-400">Tel 031) 573 - 5547 | 031) 573 - 5548</p>
            <p className="text-zinc-400">E-Mail sekwangfastener@gmail.com</p>
          </div>
          <div>
            <h4 className="font-medium mb-3">업무 시간</h4>
            <p className="text-zinc-400">평일: 09:00 - 18:00</p>
            <p className="text-zinc-400">주말 및 공휴일 휴무</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
