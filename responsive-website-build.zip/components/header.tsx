"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Phone, Menu, X } from "lucide-react"
import { useState } from "react"

export function Header() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="w-full">
      {/* Top bar */}
      <div className="bg-zinc-900 text-white text-xs md:text-sm py-2">
        <div className="max-w-6xl mx-auto px-4 flex flex-wrap justify-center md:justify-start gap-4 md:gap-8">
          <span className="flex items-center gap-1">
            <Phone className="w-3 h-3" />
            Phone 031) 573 - 5547 · 031) 573 - 5548
          </span>
          <span className="hidden md:inline">⊕ FAX 031)571 - 3567</span>
          <span className="hidden md:inline">✉ Email sekwangfastener@gmail.com</span>
        </div>
      </div>

      {/* Main navigation */}
      <nav className="bg-white border-b border-zinc-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 relative">
              <svg viewBox="0 0 40 40" className="w-full h-full">
                <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" strokeWidth="1.5"/>
                <circle cx="20" cy="20" r="6" fill="none" stroke="currentColor" strokeWidth="1.5"/>
                <line x1="20" y1="2" x2="20" y2="14" stroke="currentColor" strokeWidth="1.5"/>
                <line x1="20" y1="26" x2="20" y2="38" stroke="currentColor" strokeWidth="1.5"/>
                <line x1="2" y1="20" x2="14" y2="20" stroke="currentColor" strokeWidth="1.5"/>
                <line x1="26" y1="20" x2="38" y2="20" stroke="currentColor" strokeWidth="1.5"/>
              </svg>
            </div>
            <span className="text-xl font-medium tracking-wider">세 광 정 밀</span>
          </Link>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link 
              href="/about" 
              className={`hover:text-zinc-600 transition-colors ${pathname === '/about' ? 'font-medium' : ''}`}
            >
              회사 소개
            </Link>
            <Link 
              href="/products" 
              className={`hover:text-zinc-600 transition-colors ${pathname === '/products' ? 'font-medium' : ''}`}
            >
              제품
            </Link>
          </div>

          {/* Mobile menu button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-zinc-200">
            <Link 
              href="/about" 
              className="block px-4 py-3 hover:bg-zinc-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              회사 소개
            </Link>
            <Link 
              href="/products" 
              className="block px-4 py-3 hover:bg-zinc-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              제품
            </Link>
          </div>
        )}
      </nav>
    </header>
  )
}
