"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useState } from "react"
import { Mail, Phone, Printer, MapPin } from "lucide-react"
import Image from "next/image"

type TabType = "greeting" | "history" | "contact" | "location"

export default function AboutPage() {
  const [activeTab, setActiveTab] = useState<TabType>("greeting")

  const tabs: { id: TabType; label: string }[] = [
    { id: "greeting", label: "인사말" },
    { id: "history", label: "연혁" },
    { id: "contact", label: "연락처" },
    { id: "location", label: "오시는 길" },
  ]

  const history = [
    { year: "1998", event: "세광정밀 설립" },
    { year: "2008", event: "경기동부상공회의소 회원" },
    { year: "2018", event: "일자리 창출 기여 경기도지회의장 표창장" },
    { year: "2018", event: "일자리 창출 기여 국회의원 표창장" },
    { year: "2019", event: "경기도중소기업CEO연합회 인증기업" },
    { year: "2019", event: "경기도중소기업CEO연합회 표창장" },
    { year: "2019", event: "중소기업융합경기협회 융합회원사" },
    { year: "2020", event: "한국기업데이터 기술역량 우수기업 인증" },
    { year: "2021", event: "지역경제 활성화 경기도지사 표창장" },
    { year: "2021", event: "지역경제 활성화 남양주시장 표창장" },
    { year: "2023", event: "경기도 중소기업 벤치기업 청장 표창장" },
    { year: "2023", event: "경기도중소기업CEO연합회 남양주 지회 11대 · 12대 회장 역임" },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[200px] md:h-[300px] bg-zinc-800">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/02%20%E1%84%92%E1%85%AC%E1%84%89%E1%85%A1%20%E1%84%89%E1%85%A9%E1%84%80%E1%85%A2-xeR2X44iA2dBOJHFheQzmcnGa5OJ4a.png"
          alt="세광정밀 공장 내부"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-white text-center px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">회사 소개</h1>
          <p className="text-zinc-300">최고의 품질과 기술력으로 고객의 신뢰에 보답합니다</p>
        </div>
      </section>

      {/* Tabs */}
      <div className="border-b border-zinc-200 bg-white sticky top-0 z-30">
        <div className="max-w-4xl mx-auto">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-4 text-center text-sm md:text-base transition-colors ${
                  activeTab === tab.id 
                    ? "bg-zinc-900 text-white font-medium" 
                    : "bg-white text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="flex-1 bg-white">
        {activeTab === "greeting" && (
          <section className="py-12 md:py-20">
            <div className="max-w-3xl mx-auto px-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-8">
                <div className="w-10 h-10">
                  <svg viewBox="0 0 40 40" className="w-full h-full">
                    <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" strokeWidth="1.5"/>
                    <circle cx="20" cy="20" r="6" fill="none" stroke="currentColor" strokeWidth="1.5"/>
                    <line x1="20" y1="2" x2="20" y2="14" stroke="currentColor" strokeWidth="1.5"/>
                    <line x1="20" y1="26" x2="20" y2="38" stroke="currentColor" strokeWidth="1.5"/>
                    <line x1="2" y1="20" x2="14" y2="20" stroke="currentColor" strokeWidth="1.5"/>
                    <line x1="26" y1="20" x2="38" y2="20" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </div>
                <h2 className="text-2xl md:text-3xl font-medium tracking-wider">세 광 정 밀</h2>
              </div>
              
              <div className="space-y-6 text-zinc-600 leading-relaxed">
                <p>세광정밀에 방문해 주셔서 감사합니다.</p>
                <p>저희 세광정밀은 1998년 설립 이래로 40년의 경력과 노하우로</p>
                <p>고객 신뢰를 우선으로 생각하며, 최고 품질의 제품을 제공하고 있습니다.</p>
                <p>맞춤형 볼트 및 리벳 부터 일반형 피스, 너트, 볼트, 핀, 홈 가공 까지 고객 요구에 최적화된 제품을 제공합니다.</p>
                <p>항상 고객 감동과 최고의 품질을 제공하기 위해 최선을 다해 앞장서는 기업이 되겠습니다.</p>
              </div>
              
              <p className="mt-10 font-medium">세광정밀 대표 이승구</p>
            </div>
          </section>
        )}

        {activeTab === "history" && (
          <section className="py-12 md:py-20 bg-zinc-50">
            <div className="max-w-3xl mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-medium text-center mb-10">연혁</h2>
              <div className="space-y-4">
                {history.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-4 py-2 border-b border-zinc-200">
                    <span className="col-span-2 text-zinc-500 font-medium">{item.year}</span>
                    <span className="col-span-10 text-zinc-700">{item.event}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {activeTab === "contact" && (
          <section className="py-12 md:py-20">
            <div className="max-w-4xl mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-medium text-center mb-10">연락처</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
                  <Mail className="w-8 h-8 mx-auto mb-4 text-zinc-400" />
                  <p className="text-sm text-zinc-500 mb-2">E-mail</p>
                  <p className="font-medium">sekwangfastener@gmail.com</p>
                </div>
                <div className="border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
                  <Phone className="w-8 h-8 mx-auto mb-4 text-zinc-400" />
                  <p className="text-sm text-zinc-500 mb-2">대표전화</p>
                  <p className="font-medium">031) 573 - 5547</p>
                  <p className="font-medium">031) 573 - 5548</p>
                </div>
                <div className="border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
                  <Printer className="w-8 h-8 mx-auto mb-4 text-zinc-400" />
                  <p className="text-sm text-zinc-500 mb-2">Fax</p>
                  <p className="font-medium">031) 571 - 3567</p>
                </div>
              </div>
            </div>
          </section>
        )}

        {activeTab === "location" && (
          <section className="py-12 md:py-20 bg-zinc-50">
            <div className="max-w-4xl mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-medium text-center mb-6">오시는 길</h2>
              <p className="text-center text-zinc-600 mb-8 flex items-center justify-center gap-2">
                <MapPin className="w-5 h-5" />
                경기도 남양주시 진접읍 부마로 54-16
              </p>
              <div className="aspect-video bg-zinc-200 rounded-lg overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3156.8!2d127.1!3d37.7!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzfCsDQyJzAwLjAiTiAxMjfCsDA2JzAwLjAiRQ!5e0!3m2!1sko!2skr!4v1"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="세광정밀 위치"
                ></iframe>
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  )
}
