import { NextResponse } from 'next/server'

const SHEET_ID = '1F5RjJfH0uvAiEFnvyt7VX0GBn7wW_-hgUEcAySqJ20M'
const SHEET_GID = '884383955'
const SHEET_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&gid=${SHEET_GID}`

export async function GET() {
  try {
    const response = await fetch(SHEET_URL, {
      next: { revalidate: 60 }
    })
    
    const text = await response.text()
    const jsonString = text.substring(47).slice(0, -2)
    const data = JSON.parse(jsonString)
    
    const rows = data.table.rows
    
    interface SheetCell {
      v?: string | number | null
      f?: string
    }
    
    interface SheetRow {
      c: (SheetCell | null)[]
    }
    
    // Skip header row (first row) and map data
    const products = rows.slice(1).map((row: SheetRow) => {
      const cells = row.c
      return {
        category: cells[0]?.v || '',
        name: cells[1]?.v || '',
        spec: cells[2]?.v || '',
        image: cells[3]?.v || ''
      }
    }).filter((product: { category: string; name: string; spec: string; image: string }) => product.category && product.name)
    
    return NextResponse.json({ products })
  } catch (error) {
    console.error('Error fetching sheet data:', error)
    return NextResponse.json({ 
      products: [],
      error: 'Failed to fetch sheet data'
    })
  }
}
