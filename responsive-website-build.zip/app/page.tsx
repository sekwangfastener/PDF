import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"

export default function Home() {
  const patents = [
    { year: "2016", name: "가공물의 언더컷 성형장치", number: "제 10-1606671 호" },
    { year: "2016", name: "스위치용 핀 성형장치", number: "제 10-1689477 호" },
    { year: "2005", name: "가구용 직결볼트", number: "제 0382746 호" },
    { year: "2005", name: "이동용 캐스터의 바퀴축 구조", number: "제 0402400 호" },
    { year: "2005", name: "행거용 지지구", number: "제 0378873 호" },
    { year: "2005", name: "이동용 캐스터", number: "제 0382364 호" },
    { year: "2004", name: "체결핀의 홈 가공금형", number: "제 0363616 호" },
    { year: "2004", name: "볼트성형용 금형", number: "제 0367317 호" },
    { year: "2004", name: "가구용 연결볼트 및 그 성형기", number: "제 0345416 호" },
    { year: "2004", name: "가구용 연결볼트 및 그 성형기", number: "제 0345415 호" },
    { year: "2004", name: "가구용 연결볼트 및 그 성형기", number: "제 0345414 호" },
    { year: "1999", name: "문짝 설치용 볼트의 조정홈 가공을 위한 돌망금형", number: "제 0161943 호" },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[400px] md:h-[500px] bg-zinc-800">
        <div className="absolute inset-0 bg-black/50 z-10" />
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/01%20home-TMvIZaFG5sgd6uXwZ35JxmPU3rzcPT.png"
          alt="세광정밀 공장"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-white text-center px-4">
          <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
            40년 장인정신으로<br />
            최고의 품질을 약속합니다
          </h1>
          <p className="text-lg md:text-xl text-zinc-300 mb-2">특수 볼트 전문 기업 세광정밀</p>
          <p className="text-zinc-400">Since 1998</p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid grid-cols-3 gap-4 border border-zinc-200 rounded-lg overflow-hidden">
            <div className="text-center py-8 md:py-12 border-r border-zinc-200">
              <p className="text-3xl md:text-5xl font-light mb-2">10+</p>
              <p className="text-xs md:text-sm text-zinc-500">특허 · 실용신안 · 의장등록</p>
            </div>
            <div className="text-center py-8 md:py-12 border-r border-zinc-200">
              <p className="text-3xl md:text-5xl font-light mb-2">1,000+</p>
              <p className="text-xs md:text-sm text-zinc-500">제품 종류</p>
            </div>
            <div className="text-center py-8 md:py-12">
              <p className="text-3xl md:text-5xl font-light mb-2">300+</p>
              <p className="text-xs md:text-sm text-zinc-500">거래 기업</p>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-12 md:py-20 bg-zinc-50">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-medium text-center mb-10">인증</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <div className="text-blue-600 text-4xl font-bold">GSCF</div>
              </div>
              <p className="text-sm text-zinc-600 mb-1">경기도 중소기업 CEO 연합회</p>
              <p className="font-medium">인증기업</p>
            </div>
            <div className="bg-white border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <div className="w-16 h-16 rounded-full border-2 border-blue-600 flex items-center justify-center">
                  <span className="text-blue-600 text-2xl">融</span>
                </div>
              </div>
              <p className="text-sm text-zinc-600 mb-1">(사)중소기업융합경기연합회</p>
              <p className="font-medium">융합회원사</p>
            </div>
            <div className="bg-white border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <div className="text-green-600 text-xl font-bold">KED 한국기업데이터</div>
              </div>
              <p className="text-sm text-zinc-600 mb-1">한국기업데이터</p>
              <p className="font-medium">2020 기술역량 우수기업 인증</p>
            </div>
          </div>
        </div>
      </section>

      {/* Patents Section */}
      <section className="py-12 md:py-20 bg-zinc-900 text-white">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-medium text-center mb-10">특허 · 실용신안 · 의장등록</h2>
          <div className="space-y-3">
            {patents.map((patent, index) => (
              <div key={index} className="grid grid-cols-12 gap-4 text-sm md:text-base py-2 border-b border-zinc-700">
                <span className="col-span-2 text-zinc-400">{patent.year}</span>
                <span className="col-span-6">{patent.name}</span>
                <span className="col-span-4 text-zinc-400 text-right">{patent.number}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
