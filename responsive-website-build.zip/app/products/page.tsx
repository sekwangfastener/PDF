"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useState, useEffect } from "react"
import Image from "next/image"

type CategoryType = "볼트" | "너트" | "스크류" | "리벳" | "와셔"

interface Product {
  category: string
  name: string
  spec: string
  image: string
}

// Fallback product data
const fallbackProducts: Product[] = [
  // 볼트
  { category: "볼트", name: "연결볼트", spec: "6×10", image: "" },
  { category: "볼트", name: "연결볼트", spec: "6×15", image: "" },
  { category: "볼트", name: "연결볼트", spec: "6×30", image: "" },
  { category: "볼트", name: "연결볼트", spec: "6×50", image: "" },
  { category: "볼트", name: "연결볼트", spec: "6×60", image: "" },
  { category: "볼트", name: "연결볼트", spec: "6×65", image: "" },
  // 너트
  { category: "너트", name: "연결너트", spec: "8×15", image: "" },
  { category: "너트", name: "연결너트", spec: "8×25", image: "" },
  // 스크류
  { category: "스크류", name: "스크류", spec: "8×15", image: "" },
  { category: "스크류", name: "스크류", spec: "8×15", image: "" },
  { category: "스크류", name: "연결볼트", spec: "", image: "" },
  { category: "스크류", name: "연결볼트", spec: "", image: "" },
  // 리벳
  { category: "리벳", name: "리벳", spec: "8×15", image: "" },
  { category: "리벳", name: "리벳", spec: "8×15", image: "" },
  { category: "리벳", name: "연결볼트", spec: "", image: "" },
  { category: "리벳", name: "연결볼트", spec: "", image: "" },
  // 와셔
  { category: "와셔", name: "와셔", spec: "8×15", image: "" },
  { category: "와셔", name: "와셔", spec: "8×15", image: "" },
  { category: "와셔", name: "연결볼트", spec: "", image: "" },
  { category: "와셔", name: "연결볼트", spec: "", image: "" },
]

export default function ProductsPage() {
  const [activeCategory, setActiveCategory] = useState<CategoryType>("볼트")
  const [products, setProducts] = useState<Product[]>(fallbackProducts)
  const [loading, setLoading] = useState(true)

  const categories: CategoryType[] = ["볼트", "너트", "스크류", "리벳", "와셔"]

  useEffect(() => {
    async function fetchProducts() {
      try {
        const response = await fetch('/api/sheets')
        const data = await response.json()
        
        if (data.products && data.products.length > 0) {
          setProducts(data.products)
        }
      } catch (error) {
        console.error('[v0] Failed to fetch products from sheets:', error)
        // Keep fallback data
      } finally {
        setLoading(false)
      }
    }
    
    fetchProducts()
  }, [])

  const filteredProducts = products.filter(p => p.category === activeCategory)

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[200px] md:h-[300px] bg-zinc-800">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/03%20%E1%84%8C%E1%85%A6%E1%84%91%E1%85%AE%E1%86%B7-xTelcOWhQsHSXg9FUArA5DLp2Mvv1f.png"
          alt="볼트 제품"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-white text-center px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">제품</h1>
          <p className="text-zinc-300 text-sm md:text-base max-w-xl">
            맞춤형 볼트, 리벳 부터 일반형 피스, 너트, 볼트, 핀, 홈 가공 까지<br />
            고객 요구에 최적화된 맞춤형 제품을 제공합니다
          </p>
        </div>
      </section>

      {/* Category Tabs */}
      <div className="border-b border-zinc-200 bg-white sticky top-0 z-30">
        <div className="max-w-6xl mx-auto">
          <div className="flex">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`flex-1 py-4 text-center text-sm md:text-base transition-colors ${
                  activeCategory === category 
                    ? "bg-zinc-900 text-white font-medium" 
                    : "bg-white text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <main className="flex-1 bg-white py-12">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-xl md:text-2xl font-medium mb-8">{activeCategory}</h2>
          
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="aspect-square bg-zinc-200 rounded-lg mb-3" />
                  <div className="h-4 bg-zinc-200 rounded w-2/3" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {filteredProducts.map((product, index) => (
                <div key={index} className="group">
                  <div className="aspect-square bg-zinc-100 rounded-lg mb-3 overflow-hidden flex items-center justify-center">
                    {product.image ? (
                      <Image
                        src={product.image}
                        alt={product.name}
                        width={200}
                        height={200}
                        className="object-contain group-hover:scale-105 transition-transform"
                      />
                    ) : (
                      <div className="w-24 h-24 text-zinc-300">
                        <svg viewBox="0 0 100 100" className="w-full h-full">
                          <circle cx="50" cy="25" r="12" fill="currentColor" fillOpacity="0.3"/>
                          <rect x="45" y="37" width="10" height="50" fill="currentColor" fillOpacity="0.3"/>
                          <rect x="42" y="80" width="16" height="8" fill="currentColor" fillOpacity="0.3"/>
                        </svg>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-zinc-600">
                    {product.name} {product.spec && `${product.spec}`}
                  </p>
                </div>
              ))}
            </div>
          )}

          {filteredProducts.length === 0 && !loading && (
            <p className="text-center text-zinc-500 py-12">
              해당 카테고리에 제품이 없습니다.
            </p>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
